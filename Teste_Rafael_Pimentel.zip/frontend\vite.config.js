import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// Configuração do Vite para suportar Vue
export default defineConfig({
  plugins: [vue()]
})
